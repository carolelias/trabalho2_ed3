//funcionalidades pedidas
#include "funcoesAuxiliares.h"


// funcionalidade 8
void geraGrafo(char *arq1);

// funcionalidade 9
void geraGrafoTransposto(char *arq1);

// funcionalidade 10
void pesquisaGrafo(char *arq1, int n);

// funcionalidade 11
void conexoGrafo(char *arq1);

// funcionalidade 12
void caminhoMaisCurto(char *arq1);