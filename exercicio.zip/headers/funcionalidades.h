//funcionalidades q ela pediu
#include "funcoesAuxiliares.h"

void geraGrafo(char *arq1);