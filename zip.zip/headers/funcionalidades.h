//funcionalidades pedidas
#include "funcoesAuxiliares.h"


// funcionalidade 8
void geraGrafo(char *arq1);

//funcionalidade 9
void geraGrafoTransposto(char *arq1);